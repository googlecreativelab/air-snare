#ifndef BLE_FILE_TRANSFER_CPP
#define BLE_FILE_TRANSFER_CPP

#include <ArduinoBLE.h>

// Forward declare the function that will be called when data has been delivered to us.
void onBLEFileReceived(uint8_t* file_data, int file_length);

namespace ble_file_transfer{
  extern BLECharacteristic file_block_characteristic;
  extern BLECharacteristic file_length_characteristic;
  extern BLECharacteristic file_maximum_length_characteristic;
  extern BLECharacteristic file_checksum_characteristic;
  extern BLECharacteristic command_characteristic;
  extern BLECharacteristic transfer_status_characteristic;
  extern BLECharacteristic error_message_characteristic;

  void updateBLEFileTransfer();
  bool isTransfering();
  void setupBLEFileTransfer(BLEService service);
}

#endif // BLE_FILE_TRANSFER_CPP
